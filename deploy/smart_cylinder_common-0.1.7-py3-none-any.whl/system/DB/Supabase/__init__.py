"""Supabase persistence adapters."""
