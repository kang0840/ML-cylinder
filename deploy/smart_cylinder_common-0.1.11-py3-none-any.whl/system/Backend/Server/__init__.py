"""Flask server application factory."""
